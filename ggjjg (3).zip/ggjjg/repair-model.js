#!/usr/bin/env node

const { downloadModel, verifyGGUFFile, repairModel } = require('./ai-model/download-model.js');
const fs = require('fs');
const path = require('path');

// Colors for output
const RED = '\x1b[31m';
const GREEN = '\x1b[32m';
const YELLOW = '\x1b[33m';
const BLUE = '\x1b[34m';
const RESET = '\x1b[0m';

function printStatus(message) {
  console.log(`${BLUE}[INFO]${RESET} ${message}`);
}

function printSuccess(message) {
  console.log(`${GREEN}[SUCCESS]${RESET} ${message}`);
}

function printWarning(message) {
  console.log(`${YELLOW}[WARNING]${RESET} ${message}`);
}

function printError(message) {
  console.log(`${RED}[ERROR]${RESET} ${message}`);
}

async function checkAndRepairModels() {
  console.log('🔧 Pi ChatBot - Model Repair Tool');
  console.log('==================================\n');

  const modelsDir = path.join(__dirname, 'ai-model', 'models');
  
  // Check if models directory exists
  if (!fs.existsSync(modelsDir)) {
    printError('Models directory not found!');
    console.log('Creating models directory...');
    fs.mkdirSync(modelsDir, { recursive: true });
  }

  // Find all GGUF files
  const files = fs.readdirSync(modelsDir).filter(file => file.endsWith('.gguf'));
  
  if (files.length === 0) {
    printWarning('No GGUF model files found!');
    console.log('\nAvailable models to download:');
    console.log('1. tiny-llama (0.7GB) - Recommended for Pi 5');
    console.log('2. llama-2-7b-chat (4.37GB) - Better quality');
    console.log('3. llama-2-7b (4.37GB) - Base model');
    
    const readline = require('readline');
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout
    });

    rl.question('\nWhich model would you like to download? (1-3): ', async (answer) => {
      const modelMap = {
        '1': 'tiny-llama',
        '2': 'llama-2-7b-chat',
        '3': 'llama-2-7b'
      };
      
      const modelKey = modelMap[answer];
      if (modelKey) {
        rl.close();
        try {
          printStatus(`Downloading ${modelKey}...`);
          await downloadModel(modelKey);
          printSuccess('Model downloaded successfully!');
        } catch (error) {
          printError(`Download failed: ${error.message}`);
        }
      } else {
        printError('Invalid choice!');
        rl.close();
      }
    });
    return;
  }

  console.log(`Found ${files.length} model file(s):\n`);

  let hasCorruptedFiles = false;

  // Check each file
  for (const file of files) {
    const filePath = path.join(modelsDir, file);
    printStatus(`Checking ${file}...`);
    
    const verification = verifyGGUFFile(filePath);
    
    if (verification.valid) {
      const sizeGB = (verification.size / 1024 / 1024 / 1024).toFixed(2);
      printSuccess(`✅ ${file} is valid (${sizeGB} GB)`);
    } else {
      hasCorruptedFiles = true;
      printError(`❌ ${file} is corrupted: ${verification.error}`);
      
      if (verification.magic) {
        console.log(`   Magic bytes: '${verification.magic}' (should be 'GGUF')`);
      }
    }
    console.log('');
  }

  if (!hasCorruptedFiles) {
    printSuccess('All model files are valid! No repair needed.');
    return;
  }

  // Ask user if they want to repair
  const readline = require('readline');
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });

  rl.question('Do you want to repair the corrupted files? (y/N): ', async (answer) => {
    if (answer.toLowerCase() === 'y' || answer.toLowerCase() === 'yes') {
      rl.close();
      
      for (const file of files) {
        const filePath = path.join(modelsDir, file);
        const verification = verifyGGUFFile(filePath);
        
        if (!verification.valid) {
          printStatus(`Repairing ${file}...`);
          
          // Determine model key from filename
          let modelKey = 'tiny-llama'; // default
          if (file.includes('llama-2-7b-chat')) {
            modelKey = 'llama-2-7b-chat';
          } else if (file.includes('llama-2-7b') && !file.includes('chat')) {
            modelKey = 'llama-2-7b';
          }
          
          try {
            await repairModel(modelKey);
            printSuccess(`${file} repaired successfully!`);
          } catch (error) {
            printError(`Failed to repair ${file}: ${error.message}`);
          }
        }
      }
    } else {
      rl.close();
      printStatus('Repair cancelled.');
    }
  });
}

// Auto-repair function for non-interactive use
async function autoRepair() {
  console.log('🔧 Auto-repairing corrupted models...\n');
  
  const modelsDir = path.join(__dirname, 'ai-model', 'models');
  
  if (!fs.existsSync(modelsDir)) {
    printError('Models directory not found!');
    return false;
  }

  const files = fs.readdirSync(modelsDir).filter(file => file.endsWith('.gguf'));
  
  if (files.length === 0) {
    printWarning('No model files found. Downloading TinyLlama...');
    try {
      await downloadModel('tiny-llama');
      printSuccess('TinyLlama downloaded successfully!');
      return true;
    } catch (error) {
      printError(`Download failed: ${error.message}`);
      return false;
    }
  }

  let repaired = false;
  
  for (const file of files) {
    const filePath = path.join(modelsDir, file);
    const verification = verifyGGUFFile(filePath);
    
    if (!verification.valid) {
      printStatus(`Auto-repairing ${file}...`);
      
      let modelKey = 'tiny-llama';
      if (file.includes('llama-2-7b-chat')) {
        modelKey = 'llama-2-7b-chat';
      } else if (file.includes('llama-2-7b') && !file.includes('chat')) {
        modelKey = 'llama-2-7b';
      }
      
      try {
        await repairModel(modelKey);
        printSuccess(`${file} repaired successfully!`);
        repaired = true;
      } catch (error) {
        printError(`Failed to repair ${file}: ${error.message}`);
      }
    }
  }

  if (!repaired) {
    printSuccess('All models are valid! No repair needed.');
  }
  
  return repaired;
}

// CLI interface
if (require.main === module) {
  const isAuto = process.argv.includes('--auto');
  
  if (isAuto) {
    autoRepair()
      .then((success) => {
        process.exit(success ? 0 : 1);
      })
      .catch((error) => {
        printError(`Auto-repair failed: ${error.message}`);
        process.exit(1);
      });
  } else {
    checkAndRepairModels()
      .catch((error) => {
        printError(`Repair tool failed: ${error.message}`);
        process.exit(1);
      });
  }
}

module.exports = { checkAndRepairModels, autoRepair }; 