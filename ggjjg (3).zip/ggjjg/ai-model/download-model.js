const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');

// Configuration for different model options
const models = {
  'llama-2-7b-chat': {
    url: 'https://huggingface.co/TheBloke/Llama-2-7B-Chat-GGUF/resolve/main/llama-2-7b-chat.Q4_K_M.gguf',
    filename: 'llama-2-7b-chat.Q4_K_M.gguf',
    size: '4.37 GB',
    description: 'Llama 2 7B Chat model, quantized for efficiency',
    expectedMagic: 'GGUF'
  },
  'llama-2-7b': {
    url: 'https://huggingface.co/TheBloke/Llama-2-7B-GGUF/resolve/main/llama-2-7b.Q4_K_M.gguf',
    filename: 'llama-2-7b.Q4_K_M.gguf',
    size: '4.37 GB',
    description: 'Llama 2 7B base model, quantized for efficiency',
    expectedMagic: 'GGUF'
  },
  'tiny-llama': {
    url: 'https://huggingface.co/TheBloke/TinyLlama-1.1B-Chat-v1.0-GGUF/resolve/main/tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf',
    filename: 'tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf',
    size: '0.7 GB',
    description: 'TinyLlama 1.1B Chat model, very lightweight',
    expectedMagic: 'GGUF'
  }
};

// Default model to download
const defaultModel = 'tiny-llama';

// Function to verify GGUF file integrity
function verifyGGUFFile(filePath, expectedMagic = 'GGUF') {
  try {
    if (!fs.existsSync(filePath)) {
      return { valid: false, error: 'File does not exist' };
    }

    const stats = fs.statSync(filePath);
    if (stats.size === 0) {
      return { valid: false, error: 'File is empty' };
    }

    // Read the first few bytes to check magic number
    const fd = fs.openSync(filePath, 'r');
    const buffer = Buffer.alloc(4);
    fs.readSync(fd, buffer, 0, 4, 0);
    fs.closeSync(fd);

    const magic = buffer.toString('utf8');
    if (magic !== expectedMagic) {
      return { 
        valid: false, 
        error: `Invalid magic number. Expected '${expectedMagic}', got '${magic}'`,
        magic: magic
      };
    }

    return { valid: true, size: stats.size };
  } catch (error) {
    return { valid: false, error: error.message };
  }
}

function downloadFile(url, filename, onProgress) {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(filename);
    const protocol = url.startsWith('https:') ? https : http;
    
    protocol.get(url, (response) => {
      if (response.statusCode !== 200) {
        reject(new Error(`HTTP ${response.statusCode}: ${response.statusMessage}`));
        return;
      }

      const totalSize = parseInt(response.headers['content-length'], 10);
      let downloadedSize = 0;
      
      response.on('data', (chunk) => {
        downloadedSize += chunk.length;
        const progress = totalSize ? (downloadedSize / totalSize) * 100 : 0;
        onProgress(progress, downloadedSize, totalSize);
      });
      
      response.pipe(file);
      
      file.on('finish', () => {
        file.close();
        resolve();
      });
      
      file.on('error', (err) => {
        fs.unlink(filename, () => {}); // Delete the file if there was an error
        reject(err);
      });
    }).on('error', (err) => {
      reject(err);
    });
  });
}

function formatBytes(bytes) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

async function downloadModel(modelKey = defaultModel) {
  const model = models[modelKey];
  if (!model) {
    console.error('Invalid model specified. Available models:');
    Object.keys(models).forEach(key => {
      console.log(`  ${key}: ${models[key].description} (${models[key].size})`);
    });
    return;
  }

  const modelsDir = path.join(__dirname, 'models');
  const modelPath = path.join(modelsDir, model.filename);

  // Create models directory if it doesn't exist
  if (!fs.existsSync(modelsDir)) {
    fs.mkdirSync(modelsDir, { recursive: true });
  }

  // Check if model already exists and verify it
  if (fs.existsSync(modelPath)) {
    console.log(`Model ${model.filename} already exists. Verifying integrity...`);
    const verification = verifyGGUFFile(modelPath, model.expectedMagic);
    
    if (verification.valid) {
      console.log(`✅ Model verified successfully! Size: ${formatBytes(verification.size)}`);
      return modelPath;
    } else {
      console.log(`❌ Model file is corrupted: ${verification.error}`);
      console.log('Removing corrupted file and re-downloading...');
      fs.unlinkSync(modelPath);
    }
  }

  console.log(`Downloading ${model.description}...`);
  console.log(`Size: ${model.size}`);
  console.log(`URL: ${model.url}`);
  console.log('');

  try {
    await downloadFile(model.url, modelPath, (progress, downloaded, total) => {
      const downloadedMB = formatBytes(downloaded);
      const totalMB = formatBytes(total);
      process.stdout.write(`\rProgress: ${progress.toFixed(1)}% (${downloadedMB} / ${totalMB})`);
    });
    
    console.log('\n\nDownload completed! Verifying file integrity...');
    
    // Verify the downloaded file
    const verification = verifyGGUFFile(modelPath, model.expectedMagic);
    if (verification.valid) {
      console.log(`✅ File verified successfully! Size: ${formatBytes(verification.size)}`);
      console.log(`Model saved to: ${modelPath}`);
      return modelPath;
    } else {
      console.log(`❌ Downloaded file is corrupted: ${verification.error}`);
      fs.unlinkSync(modelPath);
      throw new Error('Downloaded file is corrupted');
    }
  } catch (error) {
    console.error('\nDownload failed:', error.message);
    // Clean up partial download
    if (fs.existsSync(modelPath)) {
      fs.unlinkSync(modelPath);
    }
    throw error;
  }
}

// Function to repair corrupted models
async function repairModel(modelKey = defaultModel) {
  const model = models[modelKey];
  if (!model) {
    console.error('Invalid model specified.');
    return;
  }

  const modelsDir = path.join(__dirname, 'models');
  const modelPath = path.join(modelsDir, model.filename);

  if (fs.existsSync(modelPath)) {
    console.log('Removing corrupted model file...');
    fs.unlinkSync(modelPath);
  }

  console.log('Re-downloading model...');
  return await downloadModel(modelKey);
}

// CLI interface
if (require.main === module) {
  const modelKey = process.argv[2] || defaultModel;
  const isRepair = process.argv.includes('--repair');
  
  console.log('Pi ChatBot - Model Downloader');
  console.log('==============================\n');
  
  if (isRepair) {
    repairModel(modelKey)
      .then((modelPath) => {
        if (modelPath) {
          console.log('\n✅ Model repair completed!');
          console.log(`📁 Model location: ${modelPath}`);
        }
      })
      .catch((error) => {
        console.error('\n❌ Model repair failed:', error.message);
        process.exit(1);
      });
  } else {
    downloadModel(modelKey)
      .then((modelPath) => {
        if (modelPath) {
          console.log('\n✅ Model download completed!');
          console.log(`📁 Model location: ${modelPath}`);
          console.log('\nYou can now start the Pi ChatBot application.');
        }
      })
      .catch((error) => {
        console.error('\n❌ Download failed:', error.message);
        console.log('\nTry running with --repair flag to re-download:');
        console.log(`node download-model.js ${modelKey} --repair`);
        process.exit(1);
      });
  }
}

module.exports = { downloadModel, models, verifyGGUFFile, repairModel }; 