# Assets Directory

This directory contains application assets such as icons and images.

## Required Files

- `icon.png` - Application icon (128x128 or larger recommended)
- `icon.ico` - Windows icon file (optional)
- `icon.icns` - macOS icon file (optional)

## Adding Your Own Icon

1. Create a PNG image (128x128 pixels or larger)
2. Name it `icon.png`
3. Place it in this directory

The application will automatically use this icon for:
- Desktop shortcuts
- Window title bar
- Application launcher
- Build outputs 