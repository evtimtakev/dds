// DOM Elements
const chatMessages = document.getElementById('chatMessages');
const messageInput = document.getElementById('messageInput');
const sendBtn = document.getElementById('sendBtn');
const clearBtn = document.getElementById('clearBtn');
const charCount = document.getElementById('charCount');
const statusDot = document.getElementById('statusDot');
const statusText = document.getElementById('statusText');
const modelPath = document.getElementById('modelPath');
const modelStatus = document.getElementById('modelStatus');
const sidebar = document.getElementById('sidebar');
const settingsBtn = document.getElementById('settingsBtn');
const closeSidebar = document.getElementById('closeSidebar');
const loadingOverlay = document.getElementById('loadingOverlay');
const toastContainer = document.getElementById('toastContainer');

// Settings elements
const sidebarModelPath = document.getElementById('sidebarModelPath');
const selectModelBtn = document.getElementById('selectModelBtn');
const restartModelBtn = document.getElementById('restartModelBtn');
const temperatureSlider = document.getElementById('temperatureSlider');
const temperatureValue = document.getElementById('temperatureValue');
const maxTokensInput = document.getElementById('maxTokensInput');

// System info elements
const platformInfo = document.getElementById('platformInfo');
const archInfo = document.getElementById('archInfo');
const electronVersion = document.getElementById('electronVersion');
const nodeVersion = document.getElementById('nodeVersion');

// Socket.IO connection
let socket = null;
let isTyping = false;

// Initialize the application
async function init() {
    try {
        // Load system information
        loadSystemInfo();
        
        // Initialize Socket.IO connection
        await initializeSocket();
        
        // Load model status
        await loadModelStatus();
        
        // Set up event listeners
        setupEventListeners();
        
        // Hide loading overlay
        loadingOverlay.classList.add('hidden');
        
        showToast('Application initialized successfully!', 'success');
    } catch (error) {
        console.error('Initialization error:', error);
        showToast('Failed to initialize application', 'error');
        loadingOverlay.classList.add('hidden');
    }
}

// Load system information
function loadSystemInfo() {
    platformInfo.textContent = window.electronAPI.getPlatform();
    archInfo.textContent = window.electronAPI.getArch();
    electronVersion.textContent = window.electronAPI.getVersion();
    nodeVersion.textContent = window.electronAPI.getNodeVersion();
}

// Initialize Socket.IO connection
async function initializeSocket() {
    const port = window.chatAPI.getServerPort();
    socket = io(`http://localhost:${port}`);
    
    socket.on('connect', () => {
        console.log('Connected to server');
        updateStatus('connected', 'Connected');
    });
    
    socket.on('disconnect', () => {
        console.log('Disconnected from server');
        updateStatus('disconnected', 'Disconnected');
    });
    
    socket.on('chat-response', (data) => {
        if (data.error) {
            showToast(data.error, 'error');
            removeTypingIndicator();
        } else {
            addMessage(data.message, 'assistant', data.timestamp);
            removeTypingIndicator();
        }
    });
    
    socket.on('connect_error', (error) => {
        console.error('Socket connection error:', error);
        updateStatus('error', 'Connection Error');
        showToast('Failed to connect to server', 'error');
    });
}

// Load model status
async function loadModelStatus() {
    try {
        const status = await window.electronAPI.getModelStatus();
        updateModelInfo(status);
    } catch (error) {
        console.error('Error loading model status:', error);
        updateModelInfo({ initialized: false, modelPath: 'Error loading status' });
    }
}

// Update model information display
function updateModelInfo(status) {
    const path = status.modelPath || 'No model selected';
    const isReady = status.initialized;
    
    modelPath.textContent = path.split('/').pop() || path;
    sidebarModelPath.textContent = path;
    modelStatus.textContent = isReady ? 'Ready' : 'Not initialized';
    
    if (isReady) {
        statusDot.classList.add('ready');
        statusText.textContent = 'AI Ready';
        sendBtn.disabled = false;
    } else {
        statusDot.classList.remove('ready');
        statusText.textContent = 'AI Not Ready';
        sendBtn.disabled = true;
    }
}

// Set up event listeners
function setupEventListeners() {
    // Message input
    messageInput.addEventListener('input', handleInputChange);
    messageInput.addEventListener('keydown', handleKeyDown);
    
    // Send button
    sendBtn.addEventListener('click', sendMessage);
    
    // Clear button
    clearBtn.addEventListener('click', clearChat);
    
    // Settings
    settingsBtn.addEventListener('click', toggleSidebar);
    closeSidebar.addEventListener('click', toggleSidebar);
    
    // Model management
    selectModelBtn.addEventListener('click', selectModel);
    restartModelBtn.addEventListener('click', restartModel);
    
    // Settings controls
    temperatureSlider.addEventListener('input', (e) => {
        temperatureValue.textContent = e.target.value;
    });
    
    // Auto-resize textarea
    messageInput.addEventListener('input', autoResizeTextarea);
}

// Handle input change
function handleInputChange() {
    const text = messageInput.value.trim();
    const charLength = messageInput.value.length;
    
    charCount.textContent = `${charLength}/1000`;
    sendBtn.disabled = !text || charLength === 0;
    
    // Update character count color
    if (charLength > 900) {
        charCount.style.color = '#ff9800';
    } else if (charLength > 950) {
        charCount.style.color = '#f44336';
    } else {
        charCount.style.color = 'rgba(255, 255, 255, 0.6)';
    }
}

// Handle key down events
function handleKeyDown(event) {
    if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        sendMessage();
    }
}

// Auto-resize textarea
function autoResizeTextarea() {
    messageInput.style.height = 'auto';
    messageInput.style.height = Math.min(messageInput.scrollHeight, 120) + 'px';
}

// Send message
async function sendMessage() {
    const message = messageInput.value.trim();
    if (!message || !socket) return;
    
    // Add user message to chat
    addMessage(message, 'user');
    
    // Clear input
    messageInput.value = '';
    messageInput.style.height = 'auto';
    handleInputChange();
    
    // Show typing indicator
    addTypingIndicator();
    
    // Send message to server
    try {
        socket.emit('chat-message', { message });
    } catch (error) {
        console.error('Error sending message:', error);
        showToast('Failed to send message', 'error');
        removeTypingIndicator();
    }
}

// Add message to chat
function addMessage(content, sender, timestamp = new Date().toISOString()) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}`;
    
    const time = new Date(timestamp).toLocaleTimeString();
    
    messageDiv.innerHTML = `
        <div class="message-content">${escapeHtml(content)}</div>
        <div class="message-time">${time}</div>
    `;
    
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Add typing indicator
function addTypingIndicator() {
    if (isTyping) return;
    
    isTyping = true;
    const typingDiv = document.createElement('div');
    typingDiv.className = 'message assistant typing-indicator';
    typingDiv.id = 'typingIndicator';
    typingDiv.innerHTML = `
        <div class="message-content">
            <div class="typing-indicator">
                AI is thinking
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
            </div>
        </div>
    `;
    
    chatMessages.appendChild(typingDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Remove typing indicator
function removeTypingIndicator() {
    const typingIndicator = document.getElementById('typingIndicator');
    if (typingIndicator) {
        typingIndicator.remove();
        isTyping = false;
    }
}

// Clear chat
function clearChat() {
    const messages = chatMessages.querySelectorAll('.message:not(.welcome-message)');
    messages.forEach(msg => msg.remove());
    showToast('Chat cleared', 'success');
}

// Toggle sidebar
function toggleSidebar() {
    sidebar.classList.toggle('open');
}

// Select model
async function selectModel() {
    try {
        const modelPath = await window.electronAPI.selectModel();
        if (modelPath) {
            showToast('Model selected. Please restart the model.', 'warning');
            await loadModelStatus();
        }
    } catch (error) {
        console.error('Error selecting model:', error);
        showToast('Failed to select model', 'error');
    }
}

// Restart model
async function restartModel() {
    try {
        showToast('Restarting model...', 'warning');
        const success = await window.electronAPI.restartModel();
        
        if (success) {
            showToast('Model restarted successfully!', 'success');
            await loadModelStatus();
        } else {
            showToast('Failed to restart model', 'error');
        }
    } catch (error) {
        console.error('Error restarting model:', error);
        showToast('Failed to restart model', 'error');
    }
}

// Update status
function updateStatus(status, text) {
    statusDot.className = `status-dot ${status}`;
    statusText.textContent = text;
}

// Show toast notification
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    
    toastContainer.appendChild(toast);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        toast.remove();
    }, 3000);
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Periodic status check
setInterval(async () => {
    try {
        await loadModelStatus();
    } catch (error) {
        console.error('Status check error:', error);
    }
}, 5000);

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', init);

// Handle window resize
window.addEventListener('resize', () => {
    if (window.innerWidth <= 768) {
        sidebar.classList.remove('open');
    }
}); 