const { contextBridge, ipcRenderer } = require('electron');

// Expose protected methods that allow the renderer process to use
// the ipcRenderer without exposing the entire object
contextBridge.exposeInMainWorld('electronAPI', {
  // Model management
  getModelStatus: () => ipcRenderer.invoke('get-model-status'),
  selectModel: () => ipcRenderer.invoke('select-model'),
  restartModel: () => ipcRenderer.invoke('restart-model'),
  
  // System info
  getPlatform: () => process.platform,
  getArch: () => process.arch,
  
  // App info
  getVersion: () => process.versions.electron,
  getNodeVersion: () => process.versions.node
});

// Expose a simple API for the chat functionality
contextBridge.exposeInMainWorld('chatAPI', {
  // These will be used by the renderer to communicate with the main process
  // The actual chat communication will be done via Socket.IO
  getServerPort: () => 3001
}); 