# Pi ChatBot - AI Assistant for Raspberry Pi 5

A modern, lightweight AI chat bot application built with Electron and LLaMA models, specifically optimized for Raspberry Pi 5 running Kali Linux.

## Features

- 🤖 **AI-Powered Chat**: Built-in LLaMA model support with real-time chat
- 🖥️ **Modern UI**: Beautiful, responsive interface with dark theme
- ⚡ **Lightweight**: Optimized for Raspberry Pi 5 performance
- 🔧 **Configurable**: Adjustable model parameters and settings
- 🌐 **API Support**: REST API and WebSocket endpoints
- 📱 **Responsive**: Works on desktop and mobile devices
- 🔒 **Secure**: Context isolation and proper security practices

## System Requirements

### Hardware
- **Raspberry Pi 5** (4GB or 8GB RAM recommended)
- **Storage**: At least 8GB free space (for model + application)
- **Network**: Internet connection for initial setup

### Software
- **Kali Linux** (or other Linux distributions)
- **Node.js** 18+ 
- **npm** or **yarn**

## Installation

### 1. Prerequisites

First, ensure you have Node.js installed on your Raspberry Pi:

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js 18+ (if not already installed)
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Verify installation
node --version
npm --version
```

### 2. Clone and Install

```bash
# Clone the repository
git clone <your-repo-url>
cd pi-chatbot

# Install dependencies
npm run install-deps
```

### 3. Download AI Model

The application requires a GGUF format LLaMA model. You can download a lightweight model suitable for Pi 5:

```bash
# Download TinyLlama (recommended for Pi 5 - 0.7GB)
cd ai-model
node download-model.js tiny-llama

# Or download Llama 2 7B (larger, better quality - 4.37GB)
node download-model.js llama-2-7b-chat
```

**Model Options:**
- `tiny-llama`: 0.7GB - Fastest, good for basic chat
- `llama-2-7b-chat`: 4.37GB - Better quality, slower
- `llama-2-7b`: 4.37GB - Base model version

### 4. Start the Application

```bash
# Start in development mode
npm run dev

# Start in production mode
npm start
```

## Usage

### Basic Chat
1. Launch the application
2. Wait for the AI model to initialize (status indicator will turn green)
3. Type your message in the input field
4. Press Enter or click the send button
5. The AI will respond in real-time

### Settings Panel
- Click the gear icon to open settings
- **Model Path**: Select or change the AI model
- **Temperature**: Adjust response creativity (0.0-1.0)
- **Max Tokens**: Set maximum response length
- **Restart Model**: Reload the AI model if needed

### API Endpoints

The application provides both WebSocket and REST API endpoints:

#### WebSocket (Real-time chat)
```javascript
const socket = io('http://localhost:3001');
socket.emit('chat-message', { message: 'Hello, AI!' });
socket.on('chat-response', (data) => {
    console.log(data.message);
});
```

#### REST API
```bash
# Send a chat message
curl -X POST http://localhost:3001/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello, AI!"}'

# Check status
curl http://localhost:3001/api/status
```

## Configuration

### Model Settings
The application automatically detects and uses the first GGUF model found in the `ai-model/models/` directory. You can:

1. **Change Model**: Use the settings panel to select a different model
2. **Adjust Parameters**: Modify temperature and max tokens in settings
3. **Restart Model**: Reload the model with new settings

### Performance Optimization

For better performance on Raspberry Pi 5:

1. **Use TinyLlama**: Recommended for Pi 5 due to size and speed
2. **Adjust Threads**: Modify `threads` parameter in `main.js` based on your Pi's capabilities
3. **Monitor Memory**: Ensure you have enough RAM available
4. **SSD Storage**: Use an SSD for faster model loading

### Environment Variables
```bash
# Set custom port (default: 3001)
export PI_CHATBOT_PORT=3001

# Set model path
export PI_CHATBOT_MODEL_PATH=/path/to/your/model.gguf
```

## Troubleshooting

### Common Issues

**1. Model Not Loading**
```bash
# Check if model file exists
ls -la ai-model/models/

# Verify model format
file ai-model/models/*.gguf
```

**2. Out of Memory**
- Use TinyLlama instead of larger models
- Close other applications
- Increase swap space if needed

**3. Slow Performance**
- Reduce `maxTokens` in settings
- Lower `temperature` for faster responses
- Use fewer threads in model configuration

**4. Connection Issues**
```bash
# Check if port is available
netstat -tulpn | grep 3001

# Restart the application
pkill -f electron
npm start
```

### Logs and Debugging

Enable debug mode:
```bash
npm run dev
```

Check console output for detailed error messages and model initialization status.

## Development

### Project Structure
```
pi-chatbot/
├── main.js              # Electron main process
├── preload.js           # Preload script for security
├── index.html           # Main UI
├── styles.css           # Styling
├── renderer.js          # UI logic
├── package.json         # Dependencies
├── ai-model/            # AI model directory
│   ├── models/          # GGUF model files
│   ├── download-model.js # Model downloader
│   └── package.json     # Model dependencies
└── README.md           # This file
```

### Building for Distribution

```bash
# Install electron-builder
npm install -g electron-builder

# Build for Linux
npm run build

# Build for specific architecture
npm run build -- --linux armv7l
```

### Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test on Raspberry Pi 5
5. Submit a pull request

## Security Considerations

- The application runs with context isolation enabled
- IPC communication is restricted to specific APIs
- No direct Node.js access from renderer process
- Model files should be from trusted sources

## License

MIT License - see LICENSE file for details

## Support

For issues and questions:
1. Check the troubleshooting section
2. Review console logs for error messages
3. Ensure your system meets requirements
4. Try with TinyLlama model first

## Acknowledgments

- **LLaMA**: Meta's language model
- **node-llama-cpp**: Node.js bindings for llama.cpp
- **Electron**: Cross-platform desktop framework
- **Socket.IO**: Real-time communication library

---

**Note**: This application is optimized for Raspberry Pi 5 but should work on other Linux systems with sufficient resources. 