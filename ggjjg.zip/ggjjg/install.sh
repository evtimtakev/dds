#!/bin/bash

# Pi ChatBot Installation Script for Raspberry Pi 5
# This script automates the installation process on Kali Linux

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to check system requirements
check_system() {
    print_status "Checking system requirements..."
    
    # Check if running on ARM architecture
    if [[ $(uname -m) != "aarch64" && $(uname -m) != "armv7l" ]]; then
        print_warning "This script is designed for Raspberry Pi (ARM architecture)"
        print_warning "Current architecture: $(uname -m)"
        read -p "Continue anyway? (y/N): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi
    
    # Check available memory
    local mem_gb=$(free -g | awk '/^Mem:/{print $2}')
    if [ "$mem_gb" -lt 3 ]; then
        print_warning "Low memory detected: ${mem_gb}GB"
        print_warning "Recommended: 4GB+ for optimal performance"
    fi
    
    # Check available disk space
    local disk_gb=$(df -BG . | awk 'NR==2 {print $4}' | sed 's/G//')
    if [ "$disk_gb" -lt 8 ]; then
        print_error "Insufficient disk space: ${disk_gb}GB available"
        print_error "Required: 8GB+ for model and application"
        exit 1
    fi
    
    print_success "System requirements check passed"
}

# Function to install Node.js
install_nodejs() {
    print_status "Installing Node.js..."
    
    if command_exists node; then
        local node_version=$(node --version)
        print_status "Node.js already installed: $node_version"
        
        # Check if version is 18+
        local major_version=$(echo $node_version | cut -d'v' -f2 | cut -d'.' -f1)
        if [ "$major_version" -ge 18 ]; then
            print_success "Node.js version is compatible"
            return 0
        else
            print_warning "Node.js version $node_version is too old"
        fi
    fi
    
    # Install Node.js 18+
    print_status "Adding NodeSource repository..."
    curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
    
    print_status "Installing Node.js..."
    sudo apt-get install -y nodejs
    
    # Verify installation
    if command_exists node && command_exists npm; then
        print_success "Node.js installed successfully: $(node --version)"
    else
        print_error "Failed to install Node.js"
        exit 1
    fi
}

# Function to install system dependencies
install_system_deps() {
    print_status "Installing system dependencies..."
    
    # Update package list
    sudo apt update
    
    # Install required packages
    local packages=(
        "build-essential"
        "python3"
        "python3-pip"
        "git"
        "curl"
        "wget"
        "unzip"
    )
    
    for package in "${packages[@]}"; do
        if ! dpkg -l | grep -q "^ii  $package "; then
            print_status "Installing $package..."
            sudo apt install -y "$package"
        else
            print_status "$package already installed"
        fi
    done
    
    print_success "System dependencies installed"
}

# Function to install application dependencies
install_app_deps() {
    print_status "Installing application dependencies..."
    
    if [ ! -f "package.json" ]; then
        print_error "package.json not found. Make sure you're in the project directory."
        exit 1
    fi
    
    # Install main dependencies
    print_status "Installing main dependencies..."
    npm install
    
    # Install AI model dependencies
    if [ -d "ai-model" ]; then
        print_status "Installing AI model dependencies..."
        cd ai-model
        npm install
        cd ..
    fi
    
    print_success "Application dependencies installed"
}

# Function to download AI model
download_ai_model() {
    print_status "Setting up AI model..."
    
    if [ ! -d "ai-model" ]; then
        print_error "ai-model directory not found"
        exit 1
    fi
    
    cd ai-model
    
    # Check if models directory exists
    if [ ! -d "models" ]; then
        mkdir -p models
    fi
    
    # Check if any model already exists
    if ls models/*.gguf 1> /dev/null 2>&1; then
        print_status "AI model already exists"
        cd ..
        return 0
    fi
    
    # Ask user which model to download
    echo
    print_status "Choose an AI model to download:"
    echo "1) TinyLlama (0.7GB) - Recommended for Pi 5"
    echo "2) Llama 2 7B Chat (4.37GB) - Better quality, slower"
    echo "3) Skip model download"
    echo
    
    read -p "Enter your choice (1-3): " model_choice
    
    case $model_choice in
        1)
            print_status "Downloading TinyLlama model..."
            node download-model.js tiny-llama
            ;;
        2)
            print_status "Downloading Llama 2 7B Chat model..."
            node download-model.js llama-2-7b-chat
            ;;
        3)
            print_warning "Skipping model download"
            print_warning "You'll need to download a model manually before using the application"
            ;;
        *)
            print_error "Invalid choice"
            cd ..
            exit 1
            ;;
    esac
    
    cd ..
}

# Function to create desktop shortcut
create_desktop_shortcut() {
    print_status "Creating desktop shortcut..."
    
    local desktop_file="$HOME/Desktop/pi-chatbot.desktop"
    
    cat > "$desktop_file" << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Pi ChatBot
Comment=AI Assistant for Raspberry Pi
Exec=$(pwd)/node_modules/.bin/electron .
Icon=$(pwd)/assets/icon.png
Terminal=false
Categories=Utility;Application;
EOF
    
    chmod +x "$desktop_file"
    print_success "Desktop shortcut created"
}

# Function to set up auto-start (optional)
setup_autostart() {
    print_status "Setting up auto-start..."
    
    read -p "Do you want Pi ChatBot to start automatically on boot? (y/N): " -n 1 -r
    echo
    
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        local autostart_dir="$HOME/.config/autostart"
        mkdir -p "$autostart_dir"
        
        local autostart_file="$autostart_dir/pi-chatbot.desktop"
        
        cat > "$autostart_file" << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Pi ChatBot
Comment=AI Assistant for Raspberry Pi
Exec=$(pwd)/node_modules/.bin/electron .
Icon=$(pwd)/assets/icon.png
Terminal=false
Categories=Utility;Application;
X-GNOME-Autostart-enabled=true
EOF
        
        print_success "Auto-start configured"
    else
        print_status "Auto-start skipped"
    fi
}

# Function to optimize system for Pi ChatBot
optimize_system() {
    print_status "Optimizing system for Pi ChatBot..."
    
    # Increase swap space if needed
    local swap_size=$(free -g | awk '/^Swap:/{print $2}')
    if [ "$swap_size" -lt 2 ]; then
        print_warning "Low swap space detected: ${swap_size}GB"
        read -p "Increase swap space to 2GB? (y/N): " -n 1 -r
        echo
        
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            print_status "Increasing swap space..."
            sudo fallocate -l 2G /swapfile
            sudo chmod 600 /swapfile
            sudo mkswap /swapfile
            sudo swapon /swapfile
            echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
            print_success "Swap space increased"
        fi
    fi
    
    # Set CPU governor to performance (optional)
    read -p "Set CPU governor to performance mode? (y/N): " -n 1 -r
    echo
    
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo 'GOVERNOR="performance"' | sudo tee /etc/default/cpufrequtils
        sudo systemctl enable cpufrequtils
        sudo systemctl start cpufrequtils
        print_success "CPU governor set to performance"
    fi
}

# Main installation function
main() {
    echo "=========================================="
    echo "    Pi ChatBot Installation Script"
    echo "    For Raspberry Pi 5 + Kali Linux"
    echo "=========================================="
    echo
    
    # Check if running as root
    if [ "$EUID" -eq 0 ]; then
        print_error "Please don't run this script as root"
        exit 1
    fi
    
    # Check system requirements
    check_system
    
    # Install system dependencies
    install_system_deps
    
    # Install Node.js
    install_nodejs
    
    # Install application dependencies
    install_app_deps
    
    # Download AI model
    download_ai_model
    
    # Optimize system
    optimize_system
    
    # Create desktop shortcut
    create_desktop_shortcut
    
    # Setup auto-start
    setup_autostart
    
    echo
    echo "=========================================="
    print_success "Installation completed successfully!"
    echo "=========================================="
    echo
    echo "Next steps:"
    echo "1. Start the application: npm start"
    echo "2. Or double-click the desktop shortcut"
    echo "3. Wait for the AI model to initialize"
    echo "4. Start chatting!"
    echo
    echo "For more information, see README.md"
    echo
}

# Run main function
main "$@" 