const https = require('https');
const fs = require('fs');
const path = require('path');

// Configuration for different model options
const models = {
  'llama-2-7b-chat': {
    url: 'https://huggingface.co/TheBloke/Llama-2-7B-Chat-GGUF/resolve/main/llama-2-7b-chat.Q4_K_M.gguf',
    filename: 'llama-2-7b-chat.Q4_K_M.gguf',
    size: '4.37 GB',
    description: 'Llama 2 7B Chat model, quantized for efficiency'
  },
  'llama-2-7b': {
    url: 'https://huggingface.co/TheBloke/Llama-2-7B-GGUF/resolve/main/llama-2-7b.Q4_K_M.gguf',
    filename: 'llama-2-7b.Q4_K_M.gguf',
    size: '4.37 GB',
    description: 'Llama 2 7B base model, quantized for efficiency'
  },
  'tiny-llama': {
    url: 'https://huggingface.co/TheBloke/TinyLlama-1.1B-Chat-v1.0-GGUF/resolve/main/tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf',
    filename: 'tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf',
    size: '0.7 GB',
    description: 'TinyLlama 1.1B Chat model, very lightweight'
  }
};

// Default model to download
const defaultModel = 'tiny-llama';

function downloadFile(url, filename, onProgress) {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(filename);
    
    https.get(url, (response) => {
      const totalSize = parseInt(response.headers['content-length'], 10);
      let downloadedSize = 0;
      
      response.on('data', (chunk) => {
        downloadedSize += chunk.length;
        const progress = (downloadedSize / totalSize) * 100;
        onProgress(progress, downloadedSize, totalSize);
      });
      
      response.pipe(file);
      
      file.on('finish', () => {
        file.close();
        resolve();
      });
      
      file.on('error', (err) => {
        fs.unlink(filename, () => {}); // Delete the file if there was an error
        reject(err);
      });
    }).on('error', (err) => {
      reject(err);
    });
  });
}

function formatBytes(bytes) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

async function downloadModel(modelKey = defaultModel) {
  const model = models[modelKey];
  if (!model) {
    console.error('Invalid model specified. Available models:');
    Object.keys(models).forEach(key => {
      console.log(`  ${key}: ${models[key].description} (${models[key].size})`);
    });
    return;
  }

  const modelsDir = path.join(__dirname, 'models');
  const modelPath = path.join(modelsDir, model.filename);

  // Create models directory if it doesn't exist
  if (!fs.existsSync(modelsDir)) {
    fs.mkdirSync(modelsDir, { recursive: true });
  }

  // Check if model already exists
  if (fs.existsSync(modelPath)) {
    console.log(`Model ${model.filename} already exists at ${modelPath}`);
    return modelPath;
  }

  console.log(`Downloading ${model.description}...`);
  console.log(`Size: ${model.size}`);
  console.log(`URL: ${model.url}`);
  console.log('');

  try {
    await downloadFile(model.url, modelPath, (progress, downloaded, total) => {
      const downloadedMB = formatBytes(downloaded);
      const totalMB = formatBytes(total);
      process.stdout.write(`\rProgress: ${progress.toFixed(1)}% (${downloadedMB} / ${totalMB})`);
    });
    
    console.log('\n\nDownload completed successfully!');
    console.log(`Model saved to: ${modelPath}`);
    return modelPath;
  } catch (error) {
    console.error('\nDownload failed:', error.message);
    throw error;
  }
}

// CLI interface
if (require.main === module) {
  const modelKey = process.argv[2] || defaultModel;
  
  console.log('Pi ChatBot - Model Downloader');
  console.log('==============================\n');
  
  downloadModel(modelKey)
    .then((modelPath) => {
      if (modelPath) {
        console.log('\n✅ Model download completed!');
        console.log(`📁 Model location: ${modelPath}`);
        console.log('\nYou can now start the Pi ChatBot application.');
      }
    })
    .catch((error) => {
      console.error('\n❌ Download failed:', error.message);
      process.exit(1);
    });
}

module.exports = { downloadModel, models }; 