const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const bodyParser = require('body-parser');

let mainWindow;
let aiModel = null;
let aiContext = null;
let aiSession = null;
let server = null;
let io = null;

// Express server for API endpoints
const expressApp = express();
expressApp.use(cors());
expressApp.use(bodyParser.json());

// Configuration
const config = {
  modelPath: path.join(__dirname, 'ai-model', 'models', 'llama-2-7b-chat.gguf'),
  port: 3001,
  maxTokens: 2048,
  temperature: 0.7
};

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    },
    icon: path.join(__dirname, 'assets', 'icon.png'),
    title: 'Pi ChatBot - AI Assistant'
  });

  mainWindow.loadFile('index.html');

  // Open DevTools in development
  if (process.argv.includes('--dev')) {
    mainWindow.webContents.openDevTools();
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// Alternative approach using child process for LLaMA
const { spawn } = require('child_process');

class LLaMAProcess {
  constructor(modelPath) {
    this.modelPath = modelPath;
    this.process = null;
    this.isReady = false;
  }

  async initialize() {
    return new Promise((resolve, reject) => {
      console.log('Starting LLaMA process...');
      
      // This is a simplified approach - you might want to use a proper LLaMA server
      // For now, we'll create a mock response system
      this.isReady = true;
      console.log('LLaMA process ready (mock mode)');
      resolve();
    });
  }

  async prompt(message, options = {}) {
    if (!this.isReady) {
      throw new Error('LLaMA process not ready');
    }

    // Mock response for testing
    const responses = [
      "Hello! I'm your AI assistant running on Raspberry Pi 5. How can I help you today?",
      "That's an interesting question. Let me think about that...",
      "I'm here to assist you with any questions or tasks you might have.",
      "The Raspberry Pi 5 is a great platform for AI applications like this one!",
      "I'm running locally on your device, so your conversations stay private."
    ];
    
    const randomResponse = responses[Math.floor(Math.random() * responses.length)];
    
    // Simulate processing time
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));
    
    return randomResponse;
  }

  cleanup() {
    if (this.process) {
      this.process.kill();
    }
    this.isReady = false;
  }
}

async function initializeAIModel() {
  try {
    console.log('Initializing AI model...');
    
    // Check if model file exists
    const fs = require('fs');
    if (!fs.existsSync(config.modelPath)) {
      console.log('Model file not found. Please download a compatible GGUF model.');
      console.log('Expected path:', config.modelPath);
      console.log('Using mock mode for testing...');
      
      // Create mock AI session
      aiSession = new LLaMAProcess(config.modelPath);
      await aiSession.initialize();
      return true;
    }

    // Try to load the real LLaMA module
    try {
      console.log('Attempting to load node-llama-cpp...');
      
      // Try multiple import strategies
      let LlamaModel, LlamaContext, LlamaChatSession;
      
      try {
        // Strategy 1: Dynamic import
        const llamaModule = await import('node-llama-cpp');
        LlamaModel = llamaModule.LlamaModel;
        LlamaContext = llamaModule.LlamaContext;
        LlamaChatSession = llamaModule.LlamaChatSession;
        console.log('✅ Loaded via dynamic import');
      } catch (error) {
        console.log('Dynamic import failed, trying require...');
        
        // Strategy 2: Require
        const llamaModule = require('node-llama-cpp');
        if (llamaModule.default) {
          LlamaModel = llamaModule.default.LlamaModel;
          LlamaContext = llamaModule.default.LlamaContext;
          LlamaChatSession = llamaModule.default.LlamaChatSession;
        } else {
          LlamaModel = llamaModule.LlamaModel;
          LlamaContext = llamaModule.LlamaContext;
          LlamaChatSession = llamaModule.LlamaChatSession;
        }
        console.log('✅ Loaded via require');
      }

      // Initialize the model
      console.log('Creating LlamaModel instance...');
      aiModel = new LlamaModel({
        modelPath: config.modelPath,
        contextSize: 4096,
        threads: 4,
        gpuLayers: 0
      });

      console.log('Creating LlamaContext instance...');
      aiContext = new LlamaContext({ model: aiModel });
      
      console.log('Creating LlamaChatSession instance...');
      aiSession = new LlamaChatSession({ context: aiContext });

      console.log('AI model initialized successfully!');
      return true;
      
    } catch (llamaError) {
      console.error('Failed to load real LLaMA module:', llamaError.message);
      console.log('Falling back to mock mode...');
      
      // Fallback to mock mode
      aiSession = new LLaMAProcess(config.modelPath);
      await aiSession.initialize();
      return true;
    }
    
  } catch (error) {
    console.error('Error initializing AI model:', error);
    console.error('Stack trace:', error.stack);
    return false;
  }
}

function setupExpressServer() {
  server = http.createServer(expressApp);
  io = socketIo(server, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  // Socket.IO connection handling
  io.on('connection', (socket) => {
    console.log('Client connected:', socket.id);

    socket.on('chat-message', async (data) => {
      try {
        if (!aiSession) {
          socket.emit('chat-response', {
            error: 'AI model not initialized'
          });
          return;
        }

        const response = await aiSession.prompt(data.message, {
          maxTokens: config.maxTokens,
          temperature: config.temperature
        });

        socket.emit('chat-response', {
          message: response,
          timestamp: new Date().toISOString()
        });
      } catch (error) {
        console.error('Error processing chat message:', error);
        socket.emit('chat-response', {
          error: 'Error processing message: ' + error.message
        });
      }
    });

    socket.on('disconnect', () => {
      console.log('Client disconnected:', socket.id);
    });
  });

  // REST API endpoints
  expressApp.post('/api/chat', async (req, res) => {
    try {
      const { message } = req.body;
      
      if (!aiSession) {
        return res.status(500).json({ error: 'AI model not initialized' });
      }

      const response = await aiSession.prompt(message, {
        maxTokens: config.maxTokens,
        temperature: config.temperature
      });

      res.json({
        message: response,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('API Error:', error);
      res.status(500).json({ error: 'Internal server error: ' + error.message });
    }
  });

  expressApp.get('/api/status', (req, res) => {
    res.json({
      status: aiSession ? 'ready' : 'initializing',
      model: config.modelPath,
      mode: aiSession instanceof LLaMAProcess ? 'mock' : 'real'
    });
  });

  server.listen(config.port, () => {
    console.log(`Server running on port ${config.port}`);
  });
}

// IPC handlers for main process communication
ipcMain.handle('get-model-status', () => {
  return {
    initialized: aiSession !== null,
    modelPath: config.modelPath,
    mode: aiSession instanceof LLaMAProcess ? 'mock' : 'real'
  };
});

ipcMain.handle('select-model', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: [
      { name: 'GGUF Models', extensions: ['gguf'] }
    ]
  });

  if (!result.canceled && result.filePaths.length > 0) {
    config.modelPath = result.filePaths[0];
    return config.modelPath;
  }
  return null;
});

ipcMain.handle('restart-model', async () => {
  try {
    // Clean up existing model
    if (aiSession) {
      if (aiSession.cleanup) {
        aiSession.cleanup();
      }
      aiSession = null;
    }
    if (aiContext) {
      aiContext = null;
    }
    if (aiModel) {
      aiModel = null;
    }

    // Reinitialize
    const success = await initializeAIModel();
    return success;
  } catch (error) {
    console.error('Error restarting model:', error);
    return false;
  }
});

app.whenReady().then(async () => {
  createWindow();
  setupExpressServer();
  
  // Initialize AI model
  await initializeAIModel();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

app.on('before-quit', () => {
  if (aiSession && aiSession.cleanup) {
    aiSession.cleanup();
  }
  if (server) {
    server.close();
  }
}); 