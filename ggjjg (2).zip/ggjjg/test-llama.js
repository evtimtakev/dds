#!/usr/bin/env node

// Test script to diagnose LLaMA module loading issues
console.log('=== Pi ChatBot - LLaMA Module Test ===\n');

// Check Node.js version
console.log('Node.js version:', process.version);
console.log('Platform:', process.platform);
console.log('Architecture:', process.arch);
console.log('');

// Check if node-llama-cpp is installed
try {
  const fs = require('fs');
  const path = require('path');
  
  const packageJsonPath = path.join(__dirname, 'node_modules', 'node-llama-cpp', 'package.json');
  if (fs.existsSync(packageJsonPath)) {
    const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
    console.log('node-llama-cpp version:', packageJson.version);
    console.log('node-llama-cpp type:', packageJson.type || 'commonjs');
  } else {
    console.log('❌ node-llama-cpp not found in node_modules');
    process.exit(1);
  }
} catch (error) {
  console.log('❌ Error checking node-llama-cpp:', error.message);
  process.exit(1);
}

console.log('');

// Test different import strategies
async function testImports() {
  console.log('Testing import strategies...\n');

  // Strategy 1: Dynamic import
  try {
    console.log('1. Testing dynamic import...');
    const llamaModule = await import('node-llama-cpp');
    console.log('✅ Dynamic import successful');
    console.log('   Available exports:', Object.keys(llamaModule));
    
    if (llamaModule.LlamaModel) {
      console.log('   ✅ LlamaModel found');
    } else {
      console.log('   ❌ LlamaModel not found');
    }
  } catch (error) {
    console.log('❌ Dynamic import failed:', error.message);
  }

  console.log('');

  // Strategy 2: Require with .default
  try {
    console.log('2. Testing require with .default...');
    const llamaModule = require('node-llama-cpp');
    console.log('✅ Require successful');
    console.log('   Has .default:', !!llamaModule.default);
    console.log('   Available keys:', Object.keys(llamaModule));
    
    if (llamaModule.default && llamaModule.default.LlamaModel) {
      console.log('   ✅ LlamaModel found in .default');
    } else if (llamaModule.LlamaModel) {
      console.log('   ✅ LlamaModel found directly');
    } else {
      console.log('   ❌ LlamaModel not found');
    }
  } catch (error) {
    console.log('❌ Require failed:', error.message);
  }

  console.log('');

  // Strategy 3: Check if it's an ES module
  try {
    console.log('3. Checking module type...');
    const llamaModulePath = require.resolve('node-llama-cpp');
    console.log('   Module path:', llamaModulePath);
    
    // Check if there's a package.json
    const moduleDir = path.dirname(llamaModulePath);
    const modulePackagePath = path.join(moduleDir, 'package.json');
    
    if (fs.existsSync(modulePackagePath)) {
      const modulePackage = JSON.parse(fs.readFileSync(modulePackagePath, 'utf8'));
      console.log('   Module type:', modulePackage.type || 'commonjs');
      console.log('   Main entry:', modulePackage.main || 'index.js');
    }
  } catch (error) {
    console.log('❌ Error checking module type:', error.message);
  }
}

// Run the tests
testImports().then(() => {
  console.log('\n=== Test completed ===');
  console.log('\nIf you see errors above, try:');
  console.log('1. npm install node-llama-cpp@latest');
  console.log('2. Check Node.js version (should be 18+)');
  console.log('3. Try running with: node --experimental-modules test-llama.js');
}).catch((error) => {
  console.error('Test failed:', error);
  process.exit(1);
}); 