#!/bin/bash

# Pi ChatBot Quick Start Script
# For development and testing

set -e

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    print_warning "Node.js not found. Please install Node.js 18+ first."
    exit 1
fi

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    print_warning "npm not found. Please install npm first."
    exit 1
fi

print_status "Pi ChatBot Quick Start"
echo "========================"
echo

# Check if dependencies are installed
if [ ! -d "node_modules" ]; then
    print_status "Installing dependencies..."
    npm install
fi

# Check if AI model exists
if [ ! -d "ai-model/models" ] || [ -z "$(ls -A ai-model/models/*.gguf 2>/dev/null)" ]; then
    print_warning "No AI model found!"
    echo
    echo "You need to download an AI model first:"
    echo "1. cd ai-model"
    echo "2. node download-model.js tiny-llama"
    echo "3. cd .."
    echo
    read -p "Do you want to download TinyLlama now? (y/N): " -n 1 -r
    echo
    
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        cd ai-model
        node download-model.js tiny-llama
        cd ..
    else
        print_warning "Please download a model before starting the application."
        exit 1
    fi
fi

print_success "Starting Pi ChatBot in development mode..."
echo
echo "The application will open in a new window."
echo "Press Ctrl+C to stop the application."
echo

# Start the application
npm run dev 